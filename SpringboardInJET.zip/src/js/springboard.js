define(["./appLogic"], function(app) {
    var model = [{
            "name": "Alert sum",
            "imgSrc": "css/images/alarm.svg",
            clickListener: function() { alert(app.calcSum(3, 2)) },
            "firstName": "Aname",
            "lastName": "Bname"
        },
        {
            "name": "Open OJ Dialog",
            "imgSrc": "css/images/barcode.svg",
            clickListener: function() { document.getElementById('modalDialog1').open(); },
            "firstName": "Cname",
            "lastName": "Dname"
        },
        {
            "name": "Menu Item 3",
            "imgSrc": "css/images/bell.svg",
            clickListener: null,
            "firstName": "Ename",
            "lastName": "Fname"
        },
        {
            "name": "Menu Item 4",
            "imgSrc": "css/images/calendar.svg",
            clickListener: null,
            "firstName": "Gname",
            "lastName": "Hname"
        },
        {
            "name": "Menu Item 5",
            "imgSrc": "css/images/cart.svg",
            clickListener: null,
            "firstName": "Iname",
            "lastName": "Jname"
        },
        {
            "name": "Menu Item 6",
            "imgSrc": "css/images/clubs.svg",
            clickListener: null,
            "firstName": "Kname",
            "lastName": "Lname"
        },
        {
            "name": "Menu Item 7",
            "imgSrc": "css/images/coin-dollar.svg",
            clickListener: null,
            "firstName": "Mname",
            "lastName": "Nname"
        },
        {
            "name": "Menu Item 8",
            "imgSrc": "css/images/file-play.svg",
            clickListener: null,
            "firstName": "Oname",
            "lastName": "Pname"
        },
        {
            "name": "Menu Item 9",
            "imgSrc": "css/images/file-text.svg",
            clickListener: null,
            "firstName": "Qname",
            "lastName": "Rname"
        },
        {
            "name": "Menu Item 10",
            "imgSrc": "css/images/headphones.svg",
            clickListener: null,
            "firstName": "Sname",
            "lastName": "Tname"
        },
        {
            "name": "Menu Item 11",
            "imgSrc": "css/images/home.svg",
            clickListener: null,
            "firstName": "Uname",
            "lastName": "Vname"
        },
        {
            "name": "Menu Item 12",
            "imgSrc": "css/images/keyboard.svg",
            clickListener: null,
            "firstName": "Wname",
            "lastName": "Xname"
        },
        {
            "name": "Menu Item 13",
            "imgSrc": "css/images/lifebuoy.svg",
            clickListener: null,
            "firstName": "Yname",
            "lastName": "Zname"
        },
        {
            "name": "Menu Item 14",
            "imgSrc": "css/images/map.svg",
            clickListener: null,
            "firstName": "1name",
            "lastName": "2name"
        },
        {
            "name": "Menu Item 15",
            "imgSrc": "css/images/music.svg",
            clickListener: null,
            "firstName": "3name",
            "lastName": "4name"
        },
        {
            "name": "Menu Item 16",
            "imgSrc": "css/images/pacman.svg",
            clickListener: null,
            "firstName": "5name",
            "lastName": "6name"
        },
        {
            "name": "Menu Item 17",
            "imgSrc": "css/images/pen.svg",
            clickListener: null,
            "firstName": "7name",
            "lastName": "8name"
        },
        {
            "name": "Menu Item 18",
            "imgSrc": "css/images/phone.svg",
            clickListener: null,
            "firstName": "9name",
            "lastName": "1name"
        },
        {
            "name": "Menu Item 19",
            "imgSrc": "css/images/printer.svg",
            clickListener: null,
            "firstName": "8name",
            "lastName": "7name"
        },
        {
            "name": "Menu Item 20",
            "imgSrc": "css/images/qrcode.svg",
            clickListener: null,
            "firstName": "6name",
            "lastName": "5name"
        },
        {
            "name": "Menu Item 21",
            "imgSrc": "css/images/quill.svg",
            clickListener: null,
            "firstName": "4name",
            "lastName": "3name"
        }
    ]
    return model
})