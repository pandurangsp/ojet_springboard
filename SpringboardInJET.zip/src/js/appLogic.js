define([], function() {
    var appModel = function() {
        this.calcSum = (a, b) => a + b
    }
    return new appModel();
});